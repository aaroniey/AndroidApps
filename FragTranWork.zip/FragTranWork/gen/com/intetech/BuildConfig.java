/** Automatically generated file. DO NOT MODIFY */
package com.intetech;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}